# 🤖 RAG Knowledge Assistant (Local & Google Drive)

A robust, lightweight Streamlit RAG (Retrieval-Augmented Generation) application supporting **PDF, DOCX, TXT, and Markdown** files from both **Local Uploads** and **Google Drive**.

## Features
- **Multi-Format Extraction:** Extract structured text with filename and page metadata from PDF, DOCX, TXT, and MD files.
- **Smart Chunking:** Splits documents into overlapping chunks while preserving lineage metadata.
- **Persistent Embeddings & FAISS:** Generates Sentence Transformer embeddings (`all-MiniLM-L6-v2`) and indexes them using FAISS for rapid similarity searches across sessions.
- **Hybrid Search:** Combines semantic vector similarity with keyword score matching for precise context retrieval.
- **Groq Integration:** Blazing-fast inference using Groq LLMs (`llama-3.3-70b-versatile`) with strict grounding ("Not available" if outside context).
- **Google Drive Support:** Load files or entire folders directly via Google Drive sharing links.
- **Secure Secret Management:** Uses Streamlit Secrets (`.streamlit/secrets.toml`) for API key management.

## Setup & Installation

1. Clone or download this repository.
2. Install dependencies:
   ```bash
   pip install -r requirements.txt
   ```
3. Set up your Groq API key:
   Create a folder named `.streamlit` and a file named `secrets.toml` inside it:
   ```toml
   GROQ_API_KEY = "your-groq-api-key-here"
   ```
4. Run the Streamlit app:
   ```bash
   streamlit run app.py
   ```
